// This file is intentionally left empty.
// All data is now fetched dynamically from the MongoDB database via API routes.